FILE_VER = '1.0'
OS_VER = '1.0U_XDV'

def title(): return 'test channel'

def run():
  print('Hi')
